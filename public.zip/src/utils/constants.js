export const AUTH_API_ENDPOINT = '/auth/login';
export const BASE_URL = 'http://31.97.203.184/api';
